<?php

$e_event->register("newspost", "news2cal_newspost", e_PLUGIN."news2cal/event_handler.php");

?>