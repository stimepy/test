<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs, 2011 Kris Sherrerd
*   email                : stimepy@aodhome.com
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*
*   file name           :   version.php
*   run from	        :   mem_app.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/

$MA_Version = "2.1.6";

?>
