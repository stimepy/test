<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*
*   file name           :   groupset.php
*   run from	          :   index.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/

/* forums stuff to do*/

// get group_id and forum_id.
if ($grid < 1)
{
  echo "ERROR - GS1 - ".MA_GINSICERR."! <br>";
}

//** check forum_id here also
if ($fmid < 1)
{
  echo "ERROR - GS2 - ".MA_MAFNSICERR."! <br>";
}
//$fnamqry = "SELECT `forum_name` FROM `".$prefix."_bbforums` WHERE `forum_id` = \"$fmid\"";
if ( !($fmidr = $dbz->SqlGetRow("forum_name", MA_bbforums, "`forum_id` = ".$appinfo['forum_id'])) )
{
  $msg .= "ERROR - GS3 - ".MA_UATOFTERR."! <br>";
}
else
{
  $fmname = $fmidr['forum_name'];
  if ($fmname=="")
  {
    $msg .= "WARNING - ".MA_DNFFFMARWARN."! <br><br>";
  }
}
$ptime = time();

//** create topic in bbtopics first - add last 3 fields for nuke
//$bbtopqry = "INSERT INTO ".$prefix."_bbtopics (`forum_id`, `topic_title`, `topic_poster`, `topic_time`, `topic_status`, `topic_vote`, `topic_type`) VALUES ($fmid, \"New ".$mrow['formtitle']." #".$lastapp." from ".$frmusr."\", $nu, $ptime, 0, 0, 0)";
$userinfo=$dbz->SqlGetRow("e7.phpbb_id, pb.username, pb.user_colour", E_user." as e7 inner join ".Epre.MA_bbusers." as pb on(e7.phpbb_id=pb.user_id) where e7.user_id=".$MAuser_info[0]);

$top_title="\"New ".$mrow["formtitle"]." #".$lastapp." from ".$frmusr."\"";

$bbtopresult = $dbz->SqlInsert(MA_bbtopics, array("forum_id"=>$appinfo['forum_id'], "topic_title"=>$top_title, "topic_poster"=>$userinfo['phpbb_id'], "topic_time"=>$ptime, "topic_status"=>'0', "topic_vote"=>'0', "topic_type"=>'0', "topic_first_poster_name"=>$userinfo['username'], "topic_first_poster_colour"=>$userinfo['user_colour'], "topic_last_poster_name"=>$userinfo['username'], "topic_last_poster_colour"=>$userinfo['user_colour'], "topic_last_post_subject"=>$top_title, "poll_title"=>'' ));
if(!$bbtopresult)
{
  echo "ERROR - GS5 - ".MA_UTCTIFERR."! <br>";
  exit();
}
else{
	$topid = $dbz->LastInsertId();
}





//** create post in bbposts - add last 2 fields for nuke
$bbpoqry = "INSERT INTO ".$prefix."_bbposts (`topic_id`, `forum_id`, `poster_id`, `post_time`, `poster_ip`, `post_username`, `enable_bbcode`, `enable_smilies`, `enable_sig`) VALUES ($topid, $fmid, $nu, $ptime, '$pip', '$frmusr', 0, 0, 0, 0)";
$bbporesult = $dbz->SqlInsert(MA_bbposts, array("topic_id"=>$topid, "forum_id"=>$appinfo['forum_id'], "poster_id"=>$userinfo['phpbb_id'], "post_time"=>$ptime, "poster_ip"=>$pip, "post_username"=>$userinfo['username'], "enable_bbcode"=>1, "enable_smilies"=>1, "enable_sig"=>1, "post_subject"=>$top_title, "post_text"=>$post, "post_checksum"=>md5($post), "bbcode_bitfield"=>'', "bbcode_uid"=>'', "post edit reason"=>'', "post_approved"=>1));
if(!$bbporesult)
{
  echo "ERROR - GS6 - ".MA_UTPTFERR."! <br>";
  exit();
}
else{
$poid = $dbz->LastInsertId();
}
//$bbpotqry = "INSERT INTO ".$prefix."_bbposts_text (`post_id`, `bbcode_uid`, `post_subject`, `post_text`) VALUES ($poid, 0, \"New ".$mrow['formtitle']." #".$lastapp." from ".$frmusr ."\",\"".$post."\")";

/*
//** update bbsearch
define('IN_PHPBB', 1);
define('SEARCH_WORD_TABLE', $prefix.'_bbsearch_wordlist');
define('SEARCH_MATCH_TABLE', $prefix.'_bbsearch_wordmatch');
define('POSTS_TABLE', $prefix.'_bbposts');
function message_die(){};
if (file_exists("includes/functions_search.php"))
{
  include_once("includes/functions_search.php");
  add_search_words("single", $poid, $post, "New ".$mrow['formtitle']." #".$lastapp." from ".$frmusr);
}
*/
//** update forum statistics
//$bbforqry = "UPDATE ".$prefix."_bbforums SET forum_posts = forum_posts + 1, forum_topics = forum_topics + 1, forum_last_post_id = $poid WHERE forum_id = '$fmid'";
$bbforresult = $dbz->SqlUpdate(MA_bbforums, "forum_posts=forum_posts+1, forum_topics=forum_topics+1, forum_topics_real=forum_topics_real+1, forum_last_post_id=".$poid.",forum_last_poster_id=".$userinfo['phpbb_id'].", forum_last_post_subject=".$top_title.",forum_last_post_time=".$ptime."forum_last_poster_name=".$userinfo['username'].",forum_last_poster_colour=".$userinfo['user_colour']);
if(!$bbforresult)
{
  echo "ERROR - GS9 - ".MA_UTPTFERR."! <br>";
  exit();
}



//** update user post count

if (is_user($user))
{
  //$bbusrqry = "UPDATE ".$user_prefix."_users SET user_posts = user_posts + 1 WHERE user_id = '$cookie[0]'";
  $bbusrresult = $dbz->SqlUpdate(MA_users, "user_posts = user_posts + 1 WHERE user_id = ".$userinfo['phpbb_id']);
  if(!$bbusrresult)
  {
    echo "ERROR - GS10 - ".MA_UTPTFERR."! <br>";
    exit();
  }
  
}
//if ($mrow['mailgroup'])
//{
//** create records in bbtopics_watch
  /*$usrsql = "SELECT * FROM ".$prefix."_bbuser_group AS t1, ".$user_prefix."_users AS t2 WHERE t1.group_id = '$grid' AND t1.user_id = t2.user_id";
  if( !($usrresult = $db->sql_query($usrsql)) )
  {
    echo "ERROR - GS11 - ".MA_UTPTFERR."! <br>";
    exit();
  }

  // ****  set topic to watch for all users found.
  while ($usridr = $db->sql_fetchrow($usrresult))
  {
    $grusr = $usridr['user_id'];
    $tomail = $usridr['user_email'];
    if ($mrow['topicwatch'])
    {
      $bbtopwqry = "INSERT INTO ".$prefix."_bbtopics_watch (`topic_id`, `user_id`, `notify_status`) VALUES ($topid, $grusr, 0)";
      $bbtopwresult = $db->sql_query($bbtopwqry);

      if(!$bbtopwresult)
      {
        echo "ERROR - GS12 - ".MA_UTPTFERR."! <br>";
        exit();
      }
    }
    $sql = "SELECT username, user_email, user_password, user_level FROM ".$user_prefix."_users WHERE username='$username'";
    $result = $db->sql_query($sql);

    if($db->sql_numrows($result) == 0)
    {
      die("ERROR - GS13 - ".MA_UTFYURERROR."! <br>");
    }

    $row = $db->sql_fetchrow($result);
    $user_email = $row[user_email];
    $admin_email = $mrow['admaddr'];
    $sject = MA_NEW." ".$mrow['formtitle']." ".MA_FOR." ".$frmusr."\n\r";
    $from  = "From: $adminmail\r\n";
    $from .= "Reply-To: $adminmail\r\n";
    $from .= "Return-Path: $adminmail\r\n";

    if ($htmlmail)
    {
      $encode = 1;
      $from .= "Content-Type: text/html; charset=iso-8859-1\r\n";
      $gmail = str_replace("\n\r", "<br>", $gmail);
      $gmail = str_replace("\r\n", "<br>", $gmail);
      $gmail = str_replace("\n", "<br>", $gmail);
      $gmail = str_replace("&middot;", "*", $gmail);
    }
    else
    {
      $encode = 0;
      $from .= "Content-Type: text/plain; charset=iso-8859-1\r\n";
      $gmail = str_replace("<br>", "\n\r", $gmail);
    }

    if ($htmlmail)
    {
      $gmail = "".MA_INTHE." ".$fmname." ".MA_FYWFANTXT." ".$mrow['formtitle']." ".MA_FORTXT." ".$frmusr."\n\r";
      $gmail .= MA_RVWAT.":<BR><B><I><A HREF=\"".$nukeurl."/modules.php?name=Forums&file=viewtopic&t=".$topid."\">".MA_NAPTXT."</A></I></B><BR>";
    }
    else
    {
      $gmail = "".MA_INTHE." ".$fmname." ".MA_FYWFANTXT." ".$mrow['formtitle']." ".MA_FORTXT." ".$frmusr."\n\r";
      $gmail .= MA_RIATXT.":\n\r";
      $gmail .= $nukeurl."/modules.php?name=Forums&file=viewtopic&t=".$topid."\n\r";
    }


    if (defined('PNM_IS_ACTIVE'))
    {
/*
      if ($htmlmail)
      {
        phpnukemail($admin_email, $sject, $gmail, $from, $from, $encode=1);
      }
      else
      {
*/
    //    phpnukemail($tomail, $sject, $gmail, $adminmail, $adminmail, $encode);
//      }
 //   }
  
      sendemail($tomail, $sject, $gmail, $from);



?>
