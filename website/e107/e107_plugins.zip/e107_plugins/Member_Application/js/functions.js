<script type='text/javascript' >
function checkappy(i)
{
  mct = i;
  zz = 0;
  while (zz < mct)
  {
    if (((document.getElementById("data"+zz).value == \ ) || ((document.getElementById("qfmt"+zz).value == "c") && (! document.getElementById("data"+zz).checked))) && (document.getElementById("rqd"+zz).value >0))
    {
          alert( ".MA_YDNPARRERR." );
          document.getElementById("data"+zz).focus();
          return false ;
    }
    else
    {
       if (document.getElementById("qfmt"+zz).value == "v")
       {
          if ((! document.getElementById("data"+zz).value == \ ) || (document.getElementById("rqd"+zz).value >0))
          {
            rgtest = document.getElementById("data"+zz).value;
            rgcode = document.getElementById("regexdef"+zz).value;
            if (! rgtest.match(rgcode))
            {
              alert( ".MA_YDNEAVRERR.");
              document.getElementById("data"+zz).focus();
              return false ;
            }
          }
       }
    }
    if ((document.getElementById("qfmt"+zz).value == "r") && (document.getElementById("rqd"+zz).value >0))
    {
      radio_choice = false;
      for (counter = 0; counter < document.appy.elements["data"+zz].length; counter++)
      {
        if (document.appy.elements["data"+zz][counter].checked) radio_choice = true;
      }
      if (! radio_choice)
      {
          alert(".MA_YDNSARRBERR.");
          document.getElementById("data"+zz).focus();
          return false ;
      }
    }
    zz++;
  }
  document.appy.submit();
  return true ;
 }
 
function updFormNo()
{
  adminurl = /e107_plugins/Member_Application/;
  formnoval = document.appy.formno.value;
  if (formnoval<0)
  {
    formurl = adminurl + mem_app.php?Member_Application&appno=-1;
  }
  else
  {
    formurl = adminurl + admin/index.php?appno= + formnoval;
  }
  window.location = formurl;
}
</script>n