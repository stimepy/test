<?php
   $text = "some help text";
   $ns->tablerender("MyPlugin Help", $text);
?>