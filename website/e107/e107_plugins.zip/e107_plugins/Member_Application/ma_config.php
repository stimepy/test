<?php
//tables custom
define ("MA_cfg", 'ma_mapcfg');
define("MA_mapp", 'ma_mapp');
define("MA_maresp", "ma_mappresp");
define("E_users", "user");
//tables forums
define("MA_bbforums", "phpbb_forums");
define("MA_bbgroups", "phpbb_groups");
define("MA_bbtopics", "phpbb_topics");
define("MA_bbusers", "phpbb_users");
define("MA_bbposts", "phpbb_posts");
define("MA_bbuser_group","_phpbb_user_group");

//prefix
define("EPre", "e107_");
define("bbpre", "_phpbb");

//posting informain
define('X1_publicpostfile', 'mem_app.php');
define('X1_adminpostfile', 'ma_admin.php');
define('X1_linkactionoperator', '?op=');
define("X1_admin_page", "../../e107_admin/admin.php");

//parent
define('MA_parent', 'e107');

//senderinfo
define('S_name', 'Pride Council');
define('S_mail', 'No-Reply@pride-gaming.com')
?>



