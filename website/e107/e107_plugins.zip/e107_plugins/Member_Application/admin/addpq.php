<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs, 2011 Kris Sherrerd aodhome.com
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   add parent question
*	run from		    :	admin/listpq.php
*   file name           :   admin/addpq.php
*-6A
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}





$script =;

echo $output;
echo $script;
?>