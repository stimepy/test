<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   list applications
*	  run from			      :	  admin/main.php
*   file name           :   admin/applist.php
*-7A
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}


//$sqla = "SELECT * FROM `".$prefix."_MA_mappresp`,`".$user_prefix."_users` WHERE formno = $formno AND ".$prefix."_MA_mappresp.userno = ".$user_prefix."_users.user_id ORDER BY ".$prefix."_MA_mappresp.appnum DESC, ".$prefix."_MA_mappresp.adate DESC";


$output ="<table border=\"1\" align=\"center\">
  <tr>
    <td colspan=\"6\" align=\"center\">
      <h3>".MA_APPLIST."</h3>
    </td>
  </tr>
  <tr>
    <td align=\"center\">
      ".MA_APPNUM."
    </td>
    <td align=\"center\">            
      ".MA_APPLICANT."
    </td>
    <td align=\"center\">
      ".MA_DATE."
    </td>
    <td align=\"center\">
      ".MA_VIEW."
    </td>
    <td align=\"center\">
      ".MA_STATUS."
    </td>
    <td align=\"center\">
      ".MA_DELETE."
    </td>
  </tr>";

$resulta = $dbz->SqlGetAll('*', MA_mares, Epre.E_users, "WHERE formno = $formno AND ".Epre.MA_mares.".userno = ".Epre.MA_users.".user_id ORDER BY ".Epre.MA_mares.".appnum DESC, ".Epre.MA_mares.".adate DESC");
if ($resulta)
{
  foreach($resulta as $rowa)
  {
    $capp = $rowa['appnum'];
	$cadate = $rowa['adate'];
	$apst = $rowa['appstatus'];
	
    $output .="  <tr>
        <td align=\"center\">
     ".$rowa['appnum']."
        </td>
        <td align=\"left\">                
    ".$rowa['username']."
        </td>
        <td align=\"center\">
    ".$rowa['adate']."
         </td>
        <td align=\"center\">
          <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAviewapp' >
          <input type=hidden name=\"formno\" value=\"".$formno."\">
          <input type=hidden name=\"adate\" value=\"".$cadate."\">
          <input type=hidden name=\"viewa\" value=\"".$rowa['appnum']."\">
          <INPUT TYPE=IMAGE SRC=\"modules/Member_Application/images/mafile.gif\" ALT=\"".MA_VIEW."\" ALIGN=\"ABSMIDDLE\" NAME=\"enam\">
        </td>
          </form>

        <td align=\"center\">
          <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAappstatus' >
          <input type=hidden name=\"formno\" value=\"".$formno."\">
          <input type=hidden name=\"adate\" value=\"".$cadate."\">
          <input type=hidden name=\"viewa\" value=\"".$rowa['appnum']."\">
          <table align=\"center\">
            <tr>
              <td align=\"center\">";
    if ($apst==0)
    {
                $output .="R<INPUT type=\"radio\" name=\"apstat\" CHECKED value=\"0\">";
    }
    else
    {
                $output .="R<INPUT type=\"radio\" name=\"apstat\" value=\"0\">";    
    }
    
	$output .="</td>
              <td align=\"center\">";
    if ($apst==1)
    {
                $output .="D<INPUT type=\"radio\" name=\"apstat\" CHECKED value=\"1\">";
    }
    else
    {
               $output .=" D<INPUT type=\"radio\" name=\"apstat\" value=\"1\">";
    }
              $output .="</td>
              <td align=\"center\">";
    if ($apst==2)
    {
                $output .="A<INPUT type=\"radio\" name=\"apstat\" CHECKED value=\"2\">";
    }
    else
    {
                $output .="A<INPUT type=\"radio\" name=\"apstat\" value=\"2\">";
    }
              $output .="</td>
              <td>
                <INPUT TYPE=IMAGE SRC=\"modules/Member_Application/images/madisk.gif\" ALT=\"".MA_UPDATE."\">
              </td>
            </tr>
          </table>



        </td>
          </form>
    
        <td align=\"center\">
          <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAdelapp' >
          <input type=hidden name=\"formno\" value=\"".$formno."\">
          <input type=hidden name=\"adate\" value=\"".$cadate."\">
          <input type=hidden name=\"viewa\" value=\"".$rowa['appnum']."\">
          <INPUT TYPE=IMAGE SRC=\"modules/Member_Application/images/madelete.gif\" ALT=\"".MA_DELETE."\" ALIGN=\"ABSMIDDLE\" NAME=\"enam\">
          </form>
        </td>
      </tr>";

  }
}
else
{
    $output .="<tr>
      <td colspan=\"5\"align=\"center\">
        ".MA_NOAPPSONFILE."
      </td>
    </tr>";
}
 
$output .="</table>
<BR /><BR />";

echo $output;

?>