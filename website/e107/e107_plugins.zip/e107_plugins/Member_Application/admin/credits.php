<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*
*   file name           :   credits.php
*   run from	        :   Member_Application/admin/index.php
*   last edit           :   05/10/2006
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}
echo "<center><H2>".MA_PSTXT."<BR><A href=\"http://www.dbfdesigns.net\"><img src=\"http://www.dbfdesigns.net/tmp/DBFLOGOD198_97.png\"></A><BR><BR>";

?>