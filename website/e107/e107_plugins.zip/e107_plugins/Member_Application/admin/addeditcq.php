<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   admin input to add a child question or option
*	  run from			      :	  admin/listpq.php, insertq.php
*   file name           :   admin/addeditcq.php
*-5A
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}

$fnm = isset($_POST['fnm']) ? trim($_POST['fnm']) : '';
$fnam = isset($_POST['edq']) ? trim($_POST['edq']) : '';
$fmat = isset($_POST['frmat']) ? trim($_POST['frmat']) : '';

//query here to get all answeres for this question.

//$sqsql = "SELECT * FROM `".$prefix."_MA_mapp` WHERE formno = $formno AND parent = ".$fnm." ORDER BY fldord

/*
    <td align=\"center\">
      Record #
    </td>
*/

$output = "<center>".$fnam."<br><br></center>

<table border=\"1\" align=\"center\">
<tr>
<td align=\"center\">
".MA_CHOICE."
 </td>
<td align=\"center\">
     ".MA_INUSE."
    </td>
    <td align=\"center\">
      ".MA_SAVE."
    </td>
    <td align=\"center\">
     ".MA_ORDER."
    </td>
  </tr>";

if ( $sqres = $dbz->SqlGetAll('*', MA_mapp, "where formno = ".$formno." AND parent = ".$fnm." ORDER BY fldord") )
{
	foreach($sqres as $sqrow){
		/*
		    <td align=\"center\">
		echo $sqrow['fldnum'];
		    </td>
	*/// echo $sqrow['fldname'];
		$r = $sqrow['fldord'];
		$p = $fnm;
		$output .= "  <tr>
	
		    <td align=\"left\">
		     <form method=post action='".X1_adminpostfile.X1_linkactionoperator."MAupdatecq' >
		      <input type=hidden name=\"formno\" value=\"".$formno."\">
		      <input type=hidden name=\"edq\" value=\"".$fnam."\">
		      <input type=hidden name=\"fnm\" value=\"".$sqrow['fldnum']."\">
		      <input type=hidden name=\"parent\" value=\"".$p."\">
		      <INPUT name=\"sqtxt\" value=\"".$sqrow['fldname']."\">
		
		    </td>
		    <td align=\"center\">";
		
		if ($sqrow['inuse'])
		{
		  $output .="      <input type=CHECKBOX name=\"inuse\" CHECKED>";
		}
		else
		{
		  $output .="      <input type=CHECKBOX name=\"inuse\">";
		}

		$output .="    </td>
		    <td align=\"center\">
		      <input type=hidden name=\"amode\" value=\"MAupdatecq\">
		      <input type=hidden name=\"ect\" value=\"".$r."\">
		      <input type=IMAGE SRC=\"../images/madisk.gif\" ALT=\"".MA_EDIT."\" ALIGN=ABSMIDDLE name=\"enam".$r."\">
		      </form>
		    </td>
		    <td align=\"center\">
		      <table>
		        <tr>
		          <td align=\"center\">
		            <form method=post action='".X1_adminpostfile.X1_linkactionoperator."MAordercq' >
		            <input type=hidden name=\"formno\" value=\"".$formno."\">
		            <input type=hidden name=\"amode\" value=\"sqorder\">
		            <input type=hidden name=\"parent\" value=\"".$p."\">
		            <input type=hidden name=\"ect\" value=\"".$r."\">
		            <input type=hidden name=\"direction\" value=\"1\">
		            <input type=hidden name=\"edq\" value=\"".$fnam."\">
		            <input type=IMAGE SRC=\"../images/mauparrow.gif\" ALT=\"".MA_UP."\" name=\"enam".$r."\">
		            </form>
		          </td>
		          <td align=\"center\">
		            <form method=post action='".X1_adminpostfile.X1_linkactionoperator."MAordercq' >
		            <input type=hidden name=\"formno\" value=\"".$formno."\">
		            <input type=hidden name=\"parent\" value=\"".$p."\">
		            <input type=hidden name=\"amode\" value=\"sqorder\">
		            <input type=hidden name=\"ect\" value=\"".$r."\">
		            <input type=hidden name=\"direction\" value=\"2\">
		            <input type=IMAGE SRC=\"../images/maarrowdn.gif\" ALT=\"".MA_DOWN."\" name=\"enam".$r."\">
		            </form>
		          </td>
		        </tr>
		      </table>
		    </td>
		  </tr>";

	}
}


$r++;
/*
    <td align=\"center\">
      Enter Choice
    </td>
*/

$output.= "  <form method='post' action='".X1_adminpostfile.X1_linkactionoperator."MAinsertq' >
  <input type=hidden name=\"formno\" value=\"".$formno."\">
  <tr>

    <td align=\"center\">
      <INPUT name=\"edq\">
    </td>
    <td align=\"center\">
      <input type=hidden name=\"ptxt\" value=\"".$fnam."\">
      <input type=hidden name=\"parent\" value=\"".$fnm."\">
      <input type=hidden name=\"fnm\" value=\"-1\">
      <input type=hidden name=\"ford\" value=\"".$r."\">
      <input type=hidden name=\"amode\" value=\"add\">
      <input type=hidden name=\"frmat\" value=\"".$fmat."\">
      <input type=checkbox name=\"inuse\">
    </td>
    <td align=\"center\">
      <input type=IMAGE SRC=\"../images/madisk.gif\" ALT=\"".MA_ADD."\" ALIGN=ABSMIDDLE name=\"Add\">
    </td>
    </form>
    <td align=\"center\">
      ".MA_NEW."
    </td>
  </tr>
</table>
<table align=\"center\">
  <tr>
    <td>
<center><I>".MA_VALIDCHILDEDIT." <img src=\"../images/madisk.gif\"> .</I></center>
    </td>
  </tr>
  <tr>
    <td valign=\"top\">
      <form method=post action='".X1_adminpostfile.X1_linkactionoperator."MAlistpq' >
      <input type=hidden name=\"formno\" value=\"".$formno."\"><center>
      <input type=SUBMIT VALUE=\"".MA_RETURN."\"></center></td><td>
      </form>
    </td>
  </tr>
</table>";

echo $output;

?>