<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   admin input for MA configuration
*   file name           :   admin/appsetup.php
*	  run from			      :	  admin/main.php
*-8A
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}

$output ="<body onload='onloadf();'>
<form name=\"frmAppSetup\" METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAconfig'>
<INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
<table align=\"center\">
  <tr>
    <td colspan=\"3\" align=\"left\">
<H4>".MA_FORMTITLE."</H4> 
    <INPUT NAME=\"formtitle\"  VALUE=\"".$row1['formtitle']."\" SIZE=\"70\" >
    </td>
  </tr>
  <tr>
    <td valign=\"top\">
    <table align=\"left\">
    <tr>
    <td>
      <br><h4>".MA_APPLICATIONTEXT."</h4>
      <i>".MA_APPTXTHINT."</i><br>
    </td>
  </tr>
  <tr>
    <TD align=\"left\">
      <TEXTAREA NAME=\"edcfg\" COLS=80 ROWS=10>".$row1['apptxt']."</TEXTAREA>
      <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"tedit\"><br><hr>
    </td></tr>
  <td>
  <table align=\"left\">

  <tr>
    <td>
      <B>".MA_UHMTXT."</B>
    </td>
    <TD align=\"left\">";
	
if ($row1['emhtml'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"emhtml\" CHECKED>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"emhtml\">";
}
    $output .="</td>
  </tr>
  <tr>
    <td>
      <B>Active</B>
    </td>
    <TD align=\"left\">";
if ($row1['active'])
{
        $output.="<INPUT TYPE=CHECKBOX NAME=\"active\" CHECKED'>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"active\"'>";
}
$output .="
    </td>
  </tr> 
  <tr>
    <td>
      <B>".MA_SNDADMINEMAIL."</B>
    </td>
    <TD align=\"left\">";
if ($row1['email_admin'])
{
        $output.="<INPUT TYPE=CHECKBOX NAME=\"emailadmin\" CHECKED onClick='updEmailAdmin();'>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"emailadmin\" onClick='updEmailAdmin();'>";
}
      $output .="<INPUT NAME=\"admad\" ID=\"admad\" VALUE=\"".$row1['admaddr']."\" SIZE=\"20\" style=\"display:none\">
    </td>
  </tr>
  <TR valign=\"top\">
    <td>
      <B>".MA_SNDGRPNOTIFYEMAIL."</B>
    </td>
    <TD align=\"left\">";
	

if ($row1['mailgroup'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"mailgroup\" CHECKED onClick='updMailGroup();'>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"mailgroup\" onClick='updMailGroup();'>";
}
        $output .="<LABEL for=\"watchtopic\" ID=\"wtlabel\" style=\"display:none\">".MA_TOPICWATCH."</LABEL>";
if ($row1['topicwatch'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"watchtopic\" ID=\"watchtopic\" CHECKED style=\"display:none\" value=\"Topic Watch\">";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"watchtopic\" ID=\"watchtopic\" style=\"display:none\" value=\"Topic Watch\">";
}
    $output .="</td>
  </tr>
  <TR valign=\"top\">
    <td>
      <B>".MA_DETAILON."</B>
    </td>
    <TD align=\"left\">";

if ($row1['emdetail'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"detail\" CHECKED>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"detail\">";
}

    $output .="</td>
  </tr>

  <TR valign=\"top\">
    <td>
      <B>".MA_SNDUSRNOTIFYEMAIL."</B>
    </td>
    <TD align=\"left\">";
if ($row1['emuser'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"emuser\" CHECKED>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"emuser\">";
}
    $output .="</td>
  </tr>

  <TR valign=\"top\">
    <td>
      <B>".MA_FORUMPOST."</B>
    </td>
    <TD align=\"left\">";
if ($row1['fpdetail'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"grpset\" CHECKED>";
}
else
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"grpset\">";
}
    $output .="</td>
  </tr>
  <tr>
    <td>
      <B>".MA_REVIEWFORUM."</B>
    </td>
    <td>
      <SELECT NAME=\"forumno\">";
$i=0;
global $dbz;
  //$fmsql = "SELECT * FROM `".$prefix."_bbforums`";
  if( !($fmresult = $dbz->SqlGetAll("*",MA_bbforums)) )
  {
     echo "<br>ERROR - 8A1 - ".MA_UATOFTERR."!";
    exit();
  }
foreach ($fmresult as $forumlist)
{
  if ($row1['forum_id'] == $forumlist['forum_id'])
  {
        $output .="<OPTION selected VALUE=\"".$forumlist['forum_id']."\">".$forumlist['forum_name'];
  }
  else
  {
        $output .="<OPTION VALUE=\"".$forumlist['forum_id']."\">".$forumlist['forum_name'];
  }
}
     $output .="</SELECT>
    </td>
  </tr>
  <tr>
    <td>
      <B>".MA_REVIEWGROUP."</B>
    </td>
    <td>
      <SELECT NAME=\"revgroupno\">";

$i=0;
  //$grsql = "SELECT * FROM `".$prefix."_bbgroups` WHERE group_description <> \"Personal User\"";
  if( !($grresult = $dbz->SqlGetAll('group_id, group_name',MA_bbgroups,  "where group_name not in('NEWLY_REGISTERED', 'BOTS', 'REGISTERED_COPPA', 'REGISTERED', 'GUESTS')")) )
  {
     echo "<br>ERROR - 8A2 - ".MA_UATOGTERR."!";
    exit();
  }
foreach($grresult as $grouplist)
{
  if ($row1['group_id'] == $grouplist['group_id'])
  {
        $output .="<OPTION selected VALUE=\"".$grouplist['group_id']."\">".$grouplist['group_name'];
  }
  else
  {
        $output .="<OPTION VALUE=\"".$grouplist['group_id']."\">".$grouplist['group_name'];
  }
	
}
      $output.="</SELECT>
    </td>
  </tr>


  <TR valign=\"top\">
    <td>
      <B>".MA_AUTOGROUP."</B>
    </td>
    <TD align=\"left\">";
if ($row1['auto_group'])
{
        $output.="<INPUT TYPE=CHECKBOX NAME=\"autogroup\" CHECKED onClick='updAutoGroup();'>";
}
else
{
        $output.="<INPUT TYPE=CHECKBOX NAME=\"autogroup\" onClick='updAutoGroup();'>";
}
       $output.=" <SELECT NAME=\"accgroupno\" ID=\"accgroupno\" style=\"display:none\">";
$i=0;

foreach( $grresult as $grouplist)
{
  if ($row1['group_add'] == $grouplist['group_id'])
  {
        $output .="<OPTION selected VALUE=\"".$grouplist['group_id']."\">".$grouplist['group_name'];
  }
  else
  {
       $output .=" <OPTION VALUE=\"".$grouplist['group_id']."\">".$grouplist['group_name'];
  }
}
      $output .="</SELECT>
    </td>
  </tr>
  <TR valign=\"top\">
    <td>
      <B>".MA_LIMITAPPCOUNT."</B>
    </td>
    <TD align=\"left\" rowspan=\"2\">";

if ($row1['appslimit'])
{
        $output .="<INPUT TYPE=CHECKBOX NAME=\"appslimit\" CHECKED onClick='updFormElement1();'>";
}
else
{
       $output .="<INPUT TYPE=CHECKBOX NAME=\"appslimit\" onClick='updFormElement1();'>";
}
      $output .="<INPUT NAME=\"appslimitno\" ID=\"appslimitno\" VALUE=\"".$row1['appslimitno']."\" SIZE=\"10\" style=\"display:none\">
    </td>
  </tr>
  <tr valign=\"top\">
  <td>
      ".MA_SETTOZEROSTOP."<br><br>
  </td>
  <td>
  </td>
  </tr>
  <tr valign=\"top\">
  <td >
  <B>".MA_ANONOK."</B>
  </td>
  <td align=\"left\">";
if ($row1['annon'])
{
   $output .=" <INPUT TYPE=CHECKBOX ID=\"anonappsok\" NAME=\"anonappsok\" CHECKED>";
}
else
{
   $output .="<INPUT TYPE=CHECKBOX ID=\"anonappsok\" NAME=\"anonappsok\">";
}
  $output .="</td>
  </tr>

  <tr lforms=\"top\">
  <td >
  <B>".MA_SHOWFORMS."</B>
  </td>
  <td align=\"left\">";
if ($row1['formlist'])
{
   $output .=" <INPUT TYPE=CHECKBOX ID=\"listforms\" NAME=\"listforms\" CHECKED>";
}
else
{
   $output .=" <INPUT TYPE=CHECKBOX ID=\"listforms\" NAME=\"listforms\">";
}
 $output .=" </td>
  </tr>

  <tr valign=\"top\">
  <td >
  <B>".MA_VERTICLEALIGN."</B>
  </td>
  <td align=\"left\">";
if ($row1['VertAlign'])
{
   $output .=" <INPUT TYPE=CHECKBOX ID=\"vertalign\" NAME=\"vertalign\" CHECKED>";
}
else
{
    $output .="<INPUT TYPE=CHECKBOX ID=\"vertalign\" NAME=\"vertalign\">";
}
  $output .="</td>
  </tr>

  <tr valign=\"top\">
  <td >
  <B>".MA_EDCOMPAT."</B>
  </td>
  <td align=\"left\">";
if ($row1['compat'])
{
    $output .="<INPUT TYPE=CHECKBOX ID=\"ecompat\" NAME=\"ecompat\" CHECKED>";
}
else
{
    $output .="<INPUT TYPE=CHECKBOX ID=\"ecompat\" NAME=\"ecompat\">";
}
 $output .=" </td>
  </tr>
  </table>
  </td>
  <tr>
    <td>
      <hr><H4>".MA_TYTXT."</H4>
      <i>".MA_TYTXTHINT."</i><br>
    </td>
  </tr>
  <tr>
    <TD align=\"left\">
      <TEXTAREA NAME=\"edtytxt\" COLS=80 ROWS=10>".$row1['tytxt']."</TEXTAREA>
    </td>
  <tr>
    <td>
      <br><hr><H4>".MA_NOAPPTXT."</H4>
      <i>".MA_NOAPPTXTHINT."</i><br>
    </td>
  </tr>
  <tr>
    <TD align=\"left\">
      <TEXTAREA NAME=\"noapptxt\" COLS=80 ROWS=10>".$row1['noapptxt']."</TEXTAREA><br>
    </td>
  </tr>

  <tr>
    <td>
      <br><hr><H4>".MA_APPAPROVTXT."</H4>
      <i>".MA_APPAPROVTXTHINT."</i><br>
    </td>
  </tr>
  <tr>
    <TD align=\"left\">
      <TEXTAREA NAME=\"apprtxt\" COLS=80 ROWS=10>".$row1['approvtxt']."</TEXTAREA><br>
    </td>
  </tr>
  <tr>
    <td>
      <br><hr><H4>".MA_APPDENYTXT."</H4>
      <i>".MA_APPDENYTXTHINT."</i><br>
    </td>
  </tr>
  <tr>
    <TD align=\"left\">
      <TEXTAREA NAME=\"denytxt\" COLS=80 ROWS=10>".$row1['denytxt']."</TEXTAREA><br><hr>
    </td>
  </tr>

  </table>
  </td>
  </tr>
  <tr>
    <td align=\"center\" colspan=\"2\">
      <INPUT TYPE=SUBMIT VALUE=\"".MA_SAVECHANGES."\">
    </td>
  </tr>
</table>
</form>";


$script = "<script language=\"javascript\" type=\"\">
PreTabValue = \"edcfg
function onloadf()
{
	updFormElement1();  
	updEmailAdmin();
	updMailGroup();
	updAutoGroup();
}

function updFormElement1(){
if (document.frmAppSetup.appslimit.checked == true){
document.getElementById('appslimitno').style.display = \"
} else {
document.getElementById('appslimitno').style.display = \"none  
}
}
function updEmailAdmin(){
if (document.frmAppSetup.emailadmin.checked == true){
document.getElementById('admad').style.display = \"
} else {
document.getElementById('admad').style.display = \"none  
}
}

function updAutoGroup(){
if (document.frmAppSetup.autogroup.checked == true){
document.getElementById('accgroupno').style.display = \"
} else {
document.getElementById('accgroupno').style.display = \"none  
}
}

function updMailGroup()
{
	if (document.frmAppSetup.mailgroup.checked == true)
	{
		document.getElementById('wtlabel').style.display = \"
		document.getElementById('watchtopic').style.display = \"
	} 
	else 
	{
		document.getElementById('wtlabel').style.display = \"none
		document.getElementById('watchtopic').style.display = \"none  
	}
}

</script>";

echo $output;
echo $script;

?>