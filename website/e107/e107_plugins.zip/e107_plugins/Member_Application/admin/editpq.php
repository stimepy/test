<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   admin input to edit a parent question
*	  run from			      :	  admin/listpq.php
*   file name           :   admin/editpq.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*-12A
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}


$output .="<body onload='updFormElement1();'>";

$ecount = isset($_POST['ect']) ? trim($_POST['ect']) : '';
//$sql = "SELECT * FROM `".$prefix."_MA_mapp` WHERE formno = $formno AND fldnum = ".$ecount." ORDER BY fldord";
if( !($row = $dbz->SqlGetRow('*', MA_mapp, "where formno = ".$formno." AND fldnum = ".$ecount." ORDER BY fldord")) )
{
  echo "ERROR - 12A1 - ".MA_UTOQTERROR."! <br>";
  exit();
}

if ( $row )
{
	$val = $row['fldnum'];
  $output .="<FORM NAME=\"frmQedit\" EDIT=\"qedit123\" METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAupdatepq' onLoad='updFormElement1();'>
  <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
  <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"update\">
  <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$ecount."\">
  <TABLE align=\"center\">
    <TR>
      <TD align=\"center\" colspan=\"2\">
  
        ".MA_QUESTION." # ".$val."
        <br><br> 
        <INPUT TYPE=HIDDEN NAME=\"fnm\" value=\"".$row['fldnum']."\">
      </TD>
    </TR>
    <TR>
      <TD width=\"100\">
        ".MA_QUESTORD."
      </TD>
      <TD>
        <INPUT TYPE=TEXT NAME=\"ford\" VALUE=\"".$row['fldord']."\" SIZE=2 MAXLENGTH=4 DISABLED>
        <INPUT TYPE=HIDDEN NAME=\"ford\" value=\"".$row['fldord']."\">
      </TD>
    </TR>
    <TR>
      <TD width=\"100\">
        ".MA_QUESTION."
      </TD>
      <TD>
        <TEXTAREA NAME=\"edq\" COLS=40 ROWS=6>".$row['fldname']."</TEXTAREA>
      </TD>
    </TR>
    <TR>
      <TD width=\"100\">
        ".MA_INUSE."
      </TD>
      <TD>";
  
  if ($row['inuse'])
  {
          $output .="<INPUT TYPE=CHECKBOX NAME=\"inuse\" CHECKED>";
  }
  else
  {
          $output .="<INPUT TYPE=CHECKBOX NAME=\"inuse\">";
  }

     $output .=" </TD>
    </TR>
    <TR>
      <TD width=\"100\">
        ".MA_REQUIRED."
      </TD>
      <TD>";

  if ($row['requrd'])
  {
          $output .="<INPUT TYPE=CHECKBOX NAME=\"rqrd\" id=\"rqrd\" CHECKED>";
  }
  else
  {
          $output .="<INPUT TYPE=CHECKBOX NAME=\"rqrd\" id=\"rqrd\">";
  }
      $output .="</TD>
    </TR>
    <TR>
      <TD width=\"100\">
        ".MA_FORMAT."
      </TD>
      <TD>
  
  
        <SELECT NAME=\"frmat\" onChange='updFormElement1();'>";
		// set selected type
  if ($row['format']=='L') 
  {
          $output .="<OPTION selected VALUE=\"L\">".MA_LABEL;
  }
  else
  {
         $output .=" <OPTION VALUE=\"L\">".MA_LABEL;
  }

  if ($row['format']=='t') 
  {
         $output .=" <OPTION selected VALUE=\"t\">".MA_ENTRY;
  }
  else
  {
          $output .="<OPTION VALUE=\"t\">".MA_ENTRY;
  }
  
    if ($row['format']=='v') 
  {
          $output .="<OPTION selected VALUE=\"v\">".MA_VALIDENTRY;
  }
  else
  {
          $output .="<OPTION VALUE=\"v\">".MA_VALIDENTRY;
  }

  if ($row['format']=='T')
  {
          $output .="<OPTION selected VALUE=\"T\">".MA_TEXTAREA;
  }
  else
  {
         $output .=" <OPTION VALUE=\"T\">".MA_TEXTAREA;
  }
  
  if ($row['format']=='p') 
  {
          $output .="<OPTION selected VALUE=\"p\">".MA_PSWORD;
  }
  else
  {
          $output .="<OPTION VALUE=\"p\">".MA_PSWORD;
  }

  if ($row['format']=='c')
  {
          $output .="<OPTION selected VALUE=\"c\">".MA_CHECKBOX;
  }
  else
  {
         $output .=" <OPTION VALUE=\"c\">".MA_CHECKBOX;
  }
	
  if ($row['format']=='b')
  {
          $output .="<OPTION selected VALUE=\"b\">".MA_CKBXLIST;
  }
  else
  {
          $output .="<OPTION VALUE=\"b\">".MA_CKBXLIST;
  }
	
  if ($row['format']=='l')
  {
          $output .="<OPTION selected VALUE=\"l\">".MA_DDLIST;
  }
  else
  {
         $output .=" <OPTION VALUE=\"l\">".MA_DDLIST;
  }
	
  if ($row['format']=='r')
  {
          $output .="<OPTION selected VALUE=\"r\">".MA_RADIOBUTTONS;
  }
  else
  {
          $output .="<OPTION VALUE=\"r\">".MA_RADIOBUTTONS;
  }
	
        $output .="</SELECT>
      </td>
      <td>
      </TD>
    </TR>
    <TR>
      <TD width=\"100\">
         <DIV name=\"regexl\" id=\"regexl\" style=\"display:none\">".MA_REGEXPRES."</DIV>
         <DIV name=\"deftxtl\" id=\"deftxtl\" style=\"display:none\">".MA_DEFAULTTXT."</DIV>
      </TD>
      <TD name=\"regex\" id=\"regex\" style=\"display:none\">
        <input type=\"text\" name=\"regextext\" id=\"regextext\" VALUE=\"".$row['rgextxt']."\" size=40 >
      </TD>
      <TD></TD>
      </TR>
  </TABLE>
  <BR><BR>
  <center><INPUT TYPE=SUBMIT VALUE=\"".MA_UPDATE."\"></center>
  </form>";

 
}



$script .="<script language=\"javascript\" type=\"\">
function updFormElement1(){
  ElemValue = document.frmQedit.frmat.value;
  if (ElemValue == \"v\"){
    document.getElementById('deftxtl').style.display = \"none
    document.getElementById('regex').style.display = \"
    document.getElementById('regexl').style.display = \"
    document.getElementById('rqrd').style.display = \"
  } else {
    if (ElemValue == \"t\"){
      document.getElementById('regexl').style.display = \"none
      document.getElementById('regex').style.display = \"
      document.getElementById('deftxtl').style.display = \"
      document.getElementById('rqrd').style.display = \"
    } else {
      document.getElementById('regex').style.display = \"none
      document.getElementById('regexl').style.display = \"none
      document.getElementById('deftxtl').style.display = \"none
      document.getElementById('rqrd').style.display = \"
      if ((ElemValue == \"L\") || (ElemValue == \"b\")){
        document.getElementById('rqrd').style.display = \"none
        document.getElementById('rqrd').checked = false;
      } else {
        document.getElementById('rqrd').style.display = \"
      }
    }
  }
}
</script>";

echo $output;
echo $script;

?>