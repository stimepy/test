<?php

/**
*
*
*/
function addform($update=false){
	global $dbz;
	if(USER){
		$clean_post=MAF::X1Clean($_POST, 5, 3);
		
		//Required to be set.
		$table['formno']=$clean_post['formno'];
		$table['formtitle']=$clean_post['formtitle'];
		$table['forum_id']=$clean_post['forumno'];
		$table['group_id']=$clean_post['revgroupno'];

		//The texts!
		$table['apptxt']=(isset($clean_post['edcfg']))?$clean_post['edcfg']:'N/A'; //app text
		$table['tytxt']=(isset($clean_post['edtytxt']))?$clean_post['edtytxt']:''; // thank you text
		$table['noapptxt']=(isset($clean_post['noapptxt']))? $clean_post['noapptxt']:''; //No apps accepted at this time text
		$table['approvtxt']=(isset($clean_post['apprtxt']))? $clean_post['apprtxt']:''; //approved text
		$table['denytxt']=(isset($clean_post['denytxt']))?$clean_post['denytxt']:''; //denied text
		
		
		
		if(isset($clean_post['emailadmin'])){ //if email admin
			$table['email_admin']=1;
			$table['admaddr']=$clean_post['admad'];
		}
		else{
			$table['email_admin']=0;
			$table['admaddr']='';
		}
		
		if(isset($clean_post['autogroup'])){ //if autogroup (does not work atm)
			$table['auto_group']=1;
			$table['group_add']=$clean_post['accgroupno'];
		}
		else{
			$table['auto_group']=0;
			$table['group_add']='';
		}
		if(isset($clean_post['appslimit'])){ // if app limit
			$table['appslimit']=1;
			$table['appslimitno']=$clean_post['appslimitno'];
		}
		else{
			$table['appslimit']=0;
			$table['appslimitno']='';
		}
		
		$table['emdetail']=(isset($clean_post['detail']))?1:0;//details
		$table['emuser']=(isset($clean_post['emuser']))?1:0; //email details to user
		
		$table['emhtml']=(isset($clean_post['emhtml']))?1:0;//email in html?
		$table['mailgroup']=(isset($clean_post['mailgroup']))?1:0;//email the group
		$table['topicwatch']=(isset($clean_post['watchtopic']))?1:0;//allow watch topic?
		 
		$table['active']=(isset($clean_post['active']))?1:0;//form active?

		$table['annon']=(isset($clean_post['anonappsok']))?1:0;//allow annomous apps
		$table['formlist']=(isset($clean_post['listforms']))?1:0;//list in forums
		$table['VertAlign']=(isset($clean_post['vertalign']))?1:0;//vert align.
		
		
		if($update==true){//If we are updating the table
			//set the items to be updated.
			$set="formtitle='{$table['formtitle']}', forum_id='{$table['forum_id']}', group_id='{$table['group_id']}', apptxt='{$table['apptxt']}', tytxt='{$table['tytxt']}', noapptxt='{$table['noapptxt']}', approvtxt='{$table['approvtxt']}', denytxt='{$table['denytxt']}', email_admin='{$table['email_admin']}', admaddr='{$table['admaddr']}', auto_group='{$table['auto_group']}', group_add='{$table['group_add']}', appslimit='{$table['appslimit']}', appslimitno='{$table['appslimitno']}', emdetail='{$table['emdetail']}', emuser='{$table['emuser']}', emhtml='{$table['emhtml']}', mailgroup='{$table['mailgroup']}', topicwatch='{$table['topicwatch']}', active='{$table['active']}', annon='{$table['annon']}', formlist='{$table['formlist']}', VertAlign='{$table['VertAlign']}'";

			$result = $dbz->SqlUpdate(MA_cfg, $set, " where formno={$table['formno']}");
		}
		else{//We are inserting a new table;
			$result = $dbz->SqlInsert(MA_cfg, $table);
		}
		if (!$result)
		{
		  echo "<BR>".mysql_error()."<BR>";
		  echo "ERROR - 15A1 - ".MA_UTUCTERROR."! <br>";
		  exit();
		}

		return true;
	}
	else{
		return false;
	}
}

function updateform(){
	if(addform($update=true)){
		return true;
	}
	return false;
}

function addques($formno){
	global $dbz;
	print_r($_POST);
	if(USER){
	 echo 'obo';
		$clean_post=MAF::X1Clean($_POST, 5, 3);
		$table['formno']=$formno;
		$table['fldord']=$clean_post['ford'];//parent order
		if(($clean_post['frmat'] == 'r'|| $clean_post['frmat'] == 'b'||$clean_post['frmat'] == 'l')){
			$table['subfldord']=(isset($clean_post['lsord'])?$clean_post['lsord']:0);
			$table['parent']=isset($clean_post['parent'])?$clean_post['parent']:0;
		}
		$table['fldname']=$clean_post['edq'];//question
		$table['inuse']=(isset($clean_post['inuse']))?1:0;
		$table['requrd']=(isset($clean_post['rqrd'])?1:0);
		$table['format']=$clean_post['frmat'];
		$table['rgextxt']=(isset($clean_post['regextext'])?$clean_post['regextext']:'');
	
		$result = $dbz->SqlInsert(MA_mapp, $table);
		if($result){
			return true;
		}
		
	}
	return false;
		
}

function addsubquest($formno){
	global $dbz;
	echo 'add';
	if(addques($formno)){
	 	echo 'add';
	 	$last=MAF::X1Clean($_POST['lsord']);
	 	$question=MAF::X1Clean($_POST['parent']);
		if($dbz->SqlUpdate(MA_mapp, " subfldord=".$last." where fldnum=".$question)){
			return true;
		}		
	}
	return false;				
}

?>