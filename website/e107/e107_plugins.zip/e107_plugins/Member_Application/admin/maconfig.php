<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   set MA configuration in mapcfg table
*	  run from			      :	  admin/appsetup.php
*   file name           :   admin/maconfig.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*-15A
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}



?>