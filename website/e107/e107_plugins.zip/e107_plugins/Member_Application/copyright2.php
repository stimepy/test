<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005 - 2007 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*
*   file name           :   copyright.php
*   run from	        :   index.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/

include("version.php");
echo "<br><b>Member Application Module V $MA_Version"
     ."<br>Member Application Module COPYRIGHT &copy; 2005 - 2007 Tim Leitz DBF Designs : 2011 Kris Sherrerd Aodhome <u><a href=\"http://www.aodhome.com\" target=\"new\">www.aodhome.com</a></u></b><br>\n";

?>