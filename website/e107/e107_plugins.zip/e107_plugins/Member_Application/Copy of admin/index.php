<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*
*   file name           :   admin/index.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
require_once("../../../class2.php");

if (!getperms("P")){
  die ("Access Denied");
}
include_once("../plugin_addhandlers.php");

include_once("../language/lang-english.php");
include_once("../ma_config.php");
include_once("../includes/database.class.php");
require_once("../includes/e107_database.class.php");
include_once("../version.php");

$dbz = new E107DatabaseTrans();

//global $admin_file, $module_name, $prefix, $user_prefix, $db, $op, $adminmail;

$module_name = "./";
$page_title = $lang['Member Application'];
$MA_Version;

require_once(HEADERF);




$output = "<title>".MA_TITLE."</title>\n"
    ."<center><H3>Member Application V ".$MA_Version." ".MA_ADMINPANEL."</H3></center>";

//check for setup in database
$formck = isset($_REQUEST['formno']) ? trim($_REQUEST['formno']) : '';
$op = isset($_REQUEST['op']) ? trim($_REQUEST['op']) : '';
if ((!$formck))
{ 

  //$sql1 = "SELECT * FROM `".$prefix."_MA_mapcfg` ORDER BY formno ASC";
  if ( !($row1 = $dbz->SqlGetRow('*', MA_macfg." ORDER BY formno ASC")) )
  {
    $formno = -1;
  }
  else
  {
    $formno = $row1['formno'];
  }
}
else
{
  if ($formck)
  {
    $formno = $formck;
  }
}

if ($formno >= 0){
  //$sql1 = "SELECT * FROM `".$prefix."_MA_mapcfg` WHERE formno = $formno";

  if ( !($row1 = $dbz->SqlGetRow('*', MA_mapcfg,"formno = ".$formno)) )
  {
    echo "ERROR - I1 - ".MA_UATOCTERROR."! <br>";
   
    require_once(FOOTERF);
    exit();
  }
}

//$sql = "SELECT * FROM `".$prefix."_MA_mapp` WHERE isdel < 1 AND formno = $formno ORDER BY fldord";

if($formno >= 0){
	if ( !($result = $dbz->SqlGetRow('*', MA_mapp, "isdel < 1 AND formno = ".$formno." ORDER BY fldord")) )
	{
	//  echo "ERROR - I3 - ".MA_UTOQTERROR."! <br>";
	 // require_once(FOOTERF);
	  //exit();
	}
}
//$num_rows = $db->sql_numrows($result);

// get operation desired

$i=0;

require_once("./main.php");

if ($formno == -1) $op = "MAnewform";
switch ($op)
{
  case "MAapplist":
    include_once($module_name."/applist.php");
    break;

  case "MAappstatus" :
    include_once($module_name."/appstatus.php");
    break;

  case "MAsetup" :
    include_once($module_name."/appsetup.php");
    break;

  case "MAlistpq" :
    include_once($module_name."/listpq.php");
    break;

  case "MAaddpq" :
    include_once($module_name."/addpq.php");
    break;

  case "MAinsertq" :
    include_once($module_name."/insertq.php");
    break;

  case "MAviewapp" :
    include_once($module_name."/viewapp.php");
    break;

  case "MAconfig" :
	echo ' test';
    include_once($module_name."/maconfig.php");
    break;

  case "MAnewform" :
    include_once($module_name."/newform.php");
    break;

  case "MAeditpq" :
    include_once($module_name."/editpq.php");
    break;

  case "MAupdatepq" :
    include_once($module_name."/updatepq.php");
    break;

  case "MAorderpq" :
    include_once($module_name."/orderpq.php");
    break;

  case "MAdelapp" :
    include_once($module_name."/delapp.php");
    break;

  case "MAaddeditcq" :
    include_once($module_name."/addeditcq.php");
    break;

  case "MAordercq" :
    include_once($module_name."/ordercq.php");
    break;

  case "MAupdatecq" :
    include_once($module_name."/updatecq.php");
    break;

  case "MAdeleteq" :
    include_once($module_name."/deleteq.php");
    break;

  case "error" :
    echo "<br><br><h1>";
    echo "ERROR - I4 - ".MA_AUEHOERROR."! <br>";
    echo "</h1><br><br>";
    break;

  default :
    header('Location: '.X1_adminpostfile.X1_linkactionoperator.'MAsetup&formno=0');
    break;

}

$output ="<table align='center' width='100%'>
 <tr>
  <td align='center'>
".include(  $module_name . "/copyright2.php")."
".include(  $module_name . "/credits.php")."
    </td>
  </tr>
</table>";


require_once(FOOTERF);

?>
