<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   parent question list 
*	  run from			      :	  admin/main.php
*   file name           :   admin/listpq.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*-14A
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}


$output ="<table border=\"1\" align=\"center\">
  <TR>
    <TD align=\"center\">
      ".MA_QUESTION."
    </TD>
    <TD align=\"center\">
      ".MA_ORDER."
    </TD>
    <TD align=\"center\">
      ".MA_INUSE."
    </TD>
    <TD align=\"center\">
      ".MA_REQUIRED."
    </TD>
    <TD align=\"center\">
      ".MA_FORMAT."
    </TD>
    <TD align=\"center\">
      ".MA_EDIT."
    </TD>
  </TR>";

if ( $rowz = $dbz->SqlGetAll('*', MA_mapp, "where isdel < 1 AND formno = ".$formno." ORDER BY fldord"))
{
  $i=0;
  
 foreach($rowz as $row)
  {
    if (($row['parent']==0) && ($row['fldnum'] >0))
    {
	 $r = $row['fldord'];
	 $name = $row['fldname'];
	$crow = $row['fldnum'];
       $output .="<TR>
             <TD>";
  
      if ($name)
      {
        $output .=$name;
      }
      else
      {
        $output .="&nbsp";
      }
         $output .=" </TD>
          <TD align=\"center\">
            <table>
              <tr>
                <td>
                  <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAorderpq' >
               <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
                  <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"order\">
     
                  <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$r."\">
                  <INPUT TYPE=HIDDEN NAME=\"direction\" value=\"1\">
                  <INPUT TYPE=IMAGE SRC=\"../images/mauparrow.gif\" ALT=\"Up\" NAME=\"enam".$r."\">
                  </form>
                </TD>
                <TD>
                  <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAorderpq' >
                  <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
                  <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"order\">
                  <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$r."\">
                  <INPUT TYPE=HIDDEN NAME=\"direction\" value=\"2\">
                  <INPUT TYPE=IMAGE SRC=\"../images/maarrowdn.gif\" ALT=\"Down\" NAME=\"enam".$r."\">
                  </form>
                </TD>
              </TR>
            </TABLE>

          </TD>
          <TD align=\"center\">";
      
      if ($row['inuse'])
      {
             $output .=" <INPUT TYPE=CHECKBOX NAME=\"mllist\" CHECKED DISABLED>";
      }
      else
      {
              $output .="<INPUT TYPE=CHECKBOX NAME=\"mllist\" DISABLED>";
      }
      
         $output .=" </TD>
          <TD align=\"center\">";

      if ($row['requrd'])
      {
              $output .="<INPUT TYPE=CHECKBOX NAME=\"mllst\" CHECKED DISABLED>";
      }
      else
      {
             $output .=" <INPUT TYPE=CHECKBOX NAME=\"mllst\" DISABLED>";
      }
       
        $output .="  </TD>
          <TD align=\"center\">";

      switch ($row['format'])
      {
	default  :                   

	case "L" :
	  $frmtword = MA_LABEL;
	  break;

	case "t" :
	  $frmtword = MA_ENTRY;
	  break;
					  			
	case "v" :
	  $frmtword = MA_VALIDENTRY;
	  break;
					  			
	case "T" :
	  $frmtword = MA_TEXTAREA;
	  break;
									
	case "p" :
	  $frmtword = MA_PSWORD;
	  break;
					
	case "c" :
	  $frmtword = MA_CHECKBOX;
	  break;
					
	case "b" :
	  $frmtword = MA_CKBXLIST;
	  break;
					
	case "l" :
	  $frmtword = MA_DDLIST;
	  break;
		
        case "r" :
	  $frmtword = MA_RADIOBUTTONS;
	  break;
      }
	
      $output .=$frmtword."
          </TD>
          <TD align=\"left\" width=\"48\">
            <table>
              <tr>
                <td align=\"center\" width=\"16\">
                  <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAeditpq' >
                  <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
                  <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"edit\">
      
                  <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$crow."\">
                  <INPUT TYPE=IMAGE SRC=\"../images/maedit.gif\" ALT=\"Edit\" ALIGN=ABSMIDDLE NAME=\"enam".$crow."\"> <!--//HEIGHT=20 WIDTH=16 -->
                  </form>
                </td>
                <td align=\"center\" width=\"16\">
                  <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAdeleteq' >
                  <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
                  <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"del\">

                  <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$crow."\">
                  <INPUT TYPE=IMAGE SRC=\"../images/madelete.gif\" ALT=\"Edit\" ALIGN=ABSMIDDLE NAME=\"enam".$crow."\"> <!--//HEIGHT=20 WIDTH=16 -->
                  </form>";
	
      if (($row['format'] == "l") || ($row['format'] == "r")|| ($row['format'] == "b"))
      {
	         $output .=" </td>
                  <td align=\"center\" width=\"16\">
	            <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAaddeditcq' >
              <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
	            <INPUT TYPE=HIDDEN NAME=\"edq\" value=\"".$row['fldname']."\">
	            <INPUT TYPE=HIDDEN NAME=\"fnm\" value=\"".$crow."\">
	            <INPUT TYPE=HIDDEN NAME=\"frmat\" value=\"".$row['format']."\">
	            <INPUT TYPE=IMAGE SRC=\"../images/malist.gif\" ALT=\"Options\" ALIGN=ABSMIDDLE NAME=\"enam".$crow."\"> 
	            </form>";
      }
	
               $output .=" </TD>
              </TR>
            </table>
          </TD>
        </TR>";
    } 
    
    $i++;
  } //while (( $row = $db->sql_fetchrow($result) ) && ($i<$num_rows));

  
}

$output .="</table>
<table align=\"center\" width=\"100%\">
  <tr>
    <td align=\"center\">
      <form METHOD=POST action='".X1_adminpostfile.X1_linkactionoperator."MAaddpq' >
      <INPUT TYPE=HIDDEN NAME=\"formno\" value=\"".$formno."\">
      <INPUT TYPE=HIDDEN NAME=\"amode\" value=\"add\">
      <INPUT TYPE=HIDDEN NAME=\"ect\" value=\"".$r."\">
      <INPUT TYPE=HIDDEN NAME=\"crow\" value=\"".$crow."\">
      <INPUT TYPE=SUBMIT VALUE=\"".MA_ADDQ."\"></TD><TD>
      </form>  
    </td>
  </tr>
</table>";

echo $output;

?>