<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs, 2011 Kris Sherrerd aodhome.com
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   add parent question
*	run from		    :	admin/listpq.php
*   file name           :   admin/addpq.php
*-6A
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*
***************************************************************************/
if (!getperms("P")){
  die ("Access Denied");
}

$ecount = isset($_POST['ect']) ? trim($_POST['ect']) : '';
$crow = isset($_POST['crow']) ? trim($_POST['crow']) : '';
$val = $crow + 1;
$rn = ($ecount+1);
$output ="<body onload='updFormElement1();'>
<form name=\"frmQedit\" method=post action='".X1_adminpostfile.X1_linkactionoperator."MAinsertq' >
<input type=hidden name=\"formno\" value=\"".$formno."\">
<input type=hidden name=\"amode\" value=\"insert\">
<input type=hidden name=\"ect\" value=\"".$ecount."\">
<input type=hidden name=\"formno\" value=\"".$formno."\">
<table align=\"center\">
  <tr>
    <td align=\"center\" colspan=\"2\">
      ".MA_QUESTION." # ".$val."
      <br><br>
      <input type=hidden name=\"fnm\" value=\"-1\">
      <input type=hidden name=\"ford\" value=\"".$rn."\">
    </td>
  </tr>
  <tr>
    <td width=\"100\">
      ".MA_QUESTION."
    </td>
    <td>
      <TEXTAREA NAME=\"edq\" COLS=40 ROWS=6></TEXTAREA>
    </td>
  </tr>
  <tr>
    <TD width=\"100\">
      ".MA_INUSE."
    </td>
    <td>
      <input type=CHECKBOX NAME=\"inuse\" CHECKED>
    </td>
  </tr>
  <tr>
    <TD width=\"100\">
      ".MA_REQUIRED."
    </td>
    <td>
      <input type=CHECKBOX NAME=\"rqrd\" id=\"rqrd\">
    </td>
  </tr>
  <tr>
    <td width=\"100\">
      ".MA_FORMAT."
    </td>
    <td>
      <SELECT NAME=\"frmat\" onchange='updFormElement1();'>
      <OPTION VALUE=\"L\">".MA_LABEL."
			<OPTION VALUE=\"t\">".MA_ENTRY."
			<OPTION VALUE=\"v\">".MA_VALIDENTRY."
			<OPTION VALUE=\"T\">".MA_TEXTAREA."
			<OPTION VALUE=\"p\">".MA_PSWORD."
			<OPTION VALUE=\"c\">".MA_CHECKBOX."
      <OPTION VALUE=\"b\">".MA_CKBXLIST."
			<OPTION VALUE=\"l\">".MA_DDLIST."
			<OPTION VALUE=\"r\">".MA_RADIOBUTTONS."
		</SELECT>
    </td>
  </tr>
  <tr>
    <td width=\"100\">
       <DIV name=\"regexl\" id=\"regexl\" style=\"display:none\">".MA_REGEXPRES."</DIV>
       <DIV name=\"deftxtl\" id=\"deftxtl\" style=\"display:none\">".MA_DEFAULTTXT."</DIV>
    </td>
    <td name=\"regex\" id=\"regex\" style=\"display:none\">
      <input type=\"text\" name=\"regextext\" id=\"regextext\" VALUE=\"".$row['rgextxt']."\" size=40 >
    </td>
    <td></td>
    </tr>
  <tr>
    <TD align=\"center\" colspan=\"2\">
      <BR><BR>
      <input type=SUBMIT VALUE=\"".MA_ADDQ."\">
    </td>
  </tr>
</table>
</form>";




$script ="<script language=\"javascript\" type=\"\">
function updFormElement1(){
  ElemValue = document.frmQedit.frmat.value;
  if (ElemValue == \"v\"){
    document.getElementById('deftxtl').style.display = \"none
    document.getElementById('regex').style.display = \"
    document.getElementById('regexl').style.display = \"
    document.getElementById('rqrd').style.display = \"
  } else {
    if (ElemValue == \"t\"){
      document.getElementById('regexl').style.display = \"none
      document.getElementById('regex').style.display = \"
      document.getElementById('deftxtl').style.display = \"
      document.getElementById('rqrd').style.display = \"
    } else {
      document.getElementById('regex').style.display = \"none
      document.getElementById('regexl').style.display = \"none
      document.getElementById('deftxtl').style.display = \"none
      document.getElementById('rqrd').style.display = \"
      if ((ElemValue == \"L\") || (ElemValue == \"b\")){
        document.getElementById('rqrd').style.display = \"none
        document.getElementById('rqrd').checked = false;
      } else {
        document.getElementById('rqrd').style.display = \"
      }
    }
  }
}
</script>";

echo $output;
echo $script;
?>