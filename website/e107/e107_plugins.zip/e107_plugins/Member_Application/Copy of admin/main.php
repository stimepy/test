<?php
/***************************************************************************
*                             Member Application
*                            -------------------
*   begin                : 13 Nov, 2005
*   copyright            : (C) 2005, 2006 Tim Leitz DBF Designs
*   email                : admin@dbfdesigns.net
*
*   Id: memberapplication v 2.1.4 Tim Leitz
*   Primary Function    :   display admin menu for MA
*	  run from			      :	  admin/index.php
*   file name           :   admin/main.php
*
***************************************************************************/
/***************************************************************************
*
*   This program is subject to the license agreement in the user manual.
*-16A
***************************************************************************/
if(!getperms("P")){
	exit('die');
}

$output ="<script type=\"text/javascript\" language=\"javascript\">
function updFormNo(){
  document.mainnav.submit();
}
</script>";

//$sqlform = "SELECT * FROM `".$prefix."_MA_mapcfg`";

if ( !($resultform = $dbz->SqlGetAll('*', MA_cfg)) )
{
  $resultform=false;
}


//create form here for this menu.  include return to site admin.
$output .="<form id=\"mainnav\" name=\"mainnav\" method=POST action='".X1_adminpostfile.X1_linkactionoperator."MAsetup'>

  <div align=\"center\">
<table align='center' cellpadding='2' cellspacing='8'>
  <tr>

  <td align='center'>
    <a href='".X1_adminpostfile.X1_linkactionoperator."MAsetup&formno=".$formno."' ><img src='../images/formsetup.png' border='0'></a><BR>
<a href='".X1_adminpostfile.X1_linkactionoperator."MAsetup&formno=".$formno."'>".MA_FORMSETUP."</a>
</td>

  <td align='center'>
    <a href='".X1_adminpostfile.X1_linkactionoperator."MAapplist&formno=".$formno."'><img src='../images/applist.png' border='0'></a><br>
    <a href='".X1_adminpostfile.X1_linkactionoperator."MAapplist&formno=".$formno."'>".MA_APPLIST."</a>
</td>

  <td align='center'>
    <a href='".X1_adminpostfile.X1_linkactionoperator."MAlistpq&formno=".$formno."'><img src='../images/qlist.png' border='0'></a><br>
    <a href='".X1_adminpostfile.X1_linkactionoperator."MAlistpq&formno=".$formno."'>".MA_QUESTIONLIST."</a>
</td>

  <td align='center'>
<img src='../images/chgform.png' border='0'><br>
    <SELECT ID=\"formno\" NAME=\"formno\" onchange='updFormNo();'>";
if (!$resultform)
{
      $output .="<OPTION selected VALUE=\"-1\">".MA_NFOFTXT."
      <OPTION VALUE=\"-1\">".MA_CFFTXT."";
}
else
{
      $output .="<OPTION VALUE=\"-1\">".MA_CNFTXT."";
	  
  foreach ($resultform as $rowform)
  {
  if ($rowform['formno']==$formno)
	  {
	      $output .="<OPTION selected VALUE=\"".$rowform['formno']."\">".$rowform['formtitle'];
	  }
	  else
	  {
	      $output .="<OPTION VALUE=\"".$rowform['formno']."\">".$rowform['formtitle'];
	  }
  } 
}
   $output .=" </SELECT>
</td>

  <td align='center'>
    <a href=\"../".X1_publicpostfile."?appno=".$row1['formno']."\" target=\"_blank\"><img src ='../images/viewform.png' border='0'></a><BR>
    <a href=\"../".X1_publicpostfile."?appno=".$row1['formno']."\" target=\"_blank\">".MA_VIEWFORM."</a>
</td>

  <td align='center'>
    <a href=\"".X1_adminpostfile."\"><img src='../images/admin.png' border='0'></a><BR>
    <a href=\"".X1_admin_page."\">".MA_MAINADMINISTRATION."</a>
</td>
</tr>
</table>
  </div>
</form>



<br>



<table align='center' width='100%'>\n";

echo $output;

?>
