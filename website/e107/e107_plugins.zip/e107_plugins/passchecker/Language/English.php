<?php
define("PASSCHK_1", "Password strength meter");
define("PASSCHK_2", "Milad Pazouki");
define("PASSCHK_3", "Show password strength meter under password field");
define("PASSCHK_4", "Installation succesfull ...");
define("PASSCHK_5", "Compeletley uninstalled");
	
	
?>