<?php

if (!defined('e107_INIT')) { exit; }

$front_page['e107bb'] = array('page' => $phpBBpath , 'title' => 'phpBB Forum');

?>