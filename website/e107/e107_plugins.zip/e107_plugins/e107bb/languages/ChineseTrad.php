<?php
//This file is empty because e107bb 3.1 uses a completely different language page
//When translating, please replace the full file, thank you


include_once(e_PLUGIN."e107bb/languages/English.php");

?>
