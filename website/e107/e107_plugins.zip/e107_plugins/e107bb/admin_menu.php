<?php
//Dummy File, compatibility purposes
?>