e107bb 3.1.t1
==========
Supports:
- New e107/new phpBB installations 
- New e107/existing phpBB installations
- Existing e107/new phpBB installations
- Existing e107/existing phpBB installations

(Existing installation means: Live/Production website with users activity) 

If installed, e107bb will allow you to import from e107 forum to phpBB.

e107bb Support
==============
Official Page: http://www.diporgos.com/e107bb/
Support Forums: http://www.diporgos.com/forum/

Changelog from e107bb 3.0.1
===========================
Feature: Supports Separate Login and User Name phpBB MOD
Improvement: Use e107 sql class to fetch data
Improvement: Now uses phpBB original ucp_register.php and ucp_remind.php.
Improvement: Removed phpBB Authentication Mode
Improvement: Theme Integration rewritten
Improvement: Universal Theme Integration
Improvement: Supports untouched/unmodded class2.php
Improvement: Now using phpBB Hooks
Improvement: e107bb Admin CP rewritten
Bug Fix: e107_prosilver Theme updated
Bug Fix: Fixed URL &amp; and amp; problems
Bug Fix: Fixed UTF-8 Username Encoding
Bug Fix: Fixed small resolution bug in 16 pixels version of e107bb Icon
Bug Fix: e107 Forum Import updated
Others: Removed phpBB autologin from phpBB login form
Others: Removed phpBB Login Menu
Others: Removed e107bb unused files


