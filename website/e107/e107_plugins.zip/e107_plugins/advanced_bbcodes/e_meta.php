<?php
/*
+---------------------------------------------------------------+
|        Plugin: Advanced Bbcodes
|        Version: 0.4
|        Date: 12/01/2009
|        Auteur: The_Death_Raw 
|        Email: postmaster@e107plugins.fr
|        Website: www.e107plugins.fr
|
|        Released under the terms and conditions of the
|        GNU General Public License (http://gnu.org).
+---------------------------------------------------------------+
*/

if (!defined('e107_INIT')){ exit; }

$advanced_bbcodes_path = e_PLUGIN.'advanced_bbcodes/';

echo '<link rel="stylesheet" type="text/css" href="'.$advanced_bbcodes_path.'css/advbbcodes.css">';

?>