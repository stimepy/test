<?php
/*
+---------------------------------------------------------------+
|        Akismet AntiSpam v6.0
|        coded by aSeptik
|        http://ask.altervista.org
|        aseptik@gmail.com
|        
|        Plugin for e107 (http://e107.org)
|
|        Released under the terms and conditions of the
|        GNU General Public License Version 3 (http://gnu.org).
+---------------------------------------------------------------+
*/

echo"<!-- Akismet Anti Spam -->";

?>