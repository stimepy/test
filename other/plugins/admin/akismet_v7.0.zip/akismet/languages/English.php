<?php

// ORIGINAL ENGLISH

define(AKIS_0, "You can get one registering at: <a href='http://wordpress.com'>http://wordpress.com/</a>");
define(AKIS_1, "just if you want personal redirection page! (provide full path) (otherwise leave blank)");
define(AKIS_2, " Your PHP Version");
define(AKIS_3, " Type here a pipe separated list of pseudo poster names");
define(AKIS_4, " Type here a pipe separated list of pseudo poster messages");
define(AKIS_5, " Convert Spam message into Pseudo messagge!");
define(AKIS_6, " Stop Akismet without Unistall");
?>